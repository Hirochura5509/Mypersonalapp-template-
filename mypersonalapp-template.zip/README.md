# MyPersonalApp Template

A clean Kivy + GitHub Actions setup for Android APK builds.